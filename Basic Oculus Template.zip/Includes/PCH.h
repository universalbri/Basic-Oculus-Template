#pragma once

//#define CLASS_REFEREMCE #include %s

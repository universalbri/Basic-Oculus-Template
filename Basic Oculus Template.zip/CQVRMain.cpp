#include "OVR_CAPI_GL.h"
#include "CQVRMain.h"

	CQVRMain::CQVRMain()
	{
		// Initializes LibOVR, and the Rift
		ovrInitParams initParams = { ovrInit_RequestVersion | ovrInit_FocusAware, OVR_MINOR_VERSION, NULL, 0, 0 };
		ovrResult result = ovr_Initialize(&initParams);
		VALIDATE(OVR_SUCCESS(result), "Failed to initialize libOVR.");

		VALIDATE(Platform.InitWindow(hinst, L"Oculus Room Tiny (GL)"), "Failed to open window.");

		return;
	}
	CQVRMain::~CQVRMain()
	{
		ovr_Shutdown();
		return;
	}